#' The \code{GBAT.fields_by_version} function provides a crosstab data table containing return fields available for each version of DCP's Geosupport geocoding software. These fields are described in \href{https://nycplanning.github.io/Geosupport-UPG/appendices/appendix13/}{Appendix 13 of the Geosupport System User Programming Guide}.
#' @details Geosupport can be downloaded from \href{https://www1.nyc.gov/site/planning/data-maps/open-data.page#geocoding_application}{DCP BYTES of the BIG APPLE}. Excellent documentation is provide in the \href{https://nycplanning.github.io/Geosupport-UPG/}{Geosupport System User Programming Guide}. The geocoder return fields are described in \href{https://nycplanning.github.io/Geosupport-UPG/appendices/appendix13/}{Appendix 13 of the Geosupport System User Programming Guide}.
#' @title Crosstab of return fields available for each version of Geosupport.
#' @name GBAT.fields_by_version
#' @aliases GBAT.fields_by_version
#' @import data.table
#' @export GBAT.fields_by_version 
#' @return A crosstab data frame containing return fields available for each version of DCP's Geosupport geocoding software.
#' @examples 
#' 
#' #generate crosstab
#' gc_fld_by_ver <- GBAT.fields_by_version()
#' 
#' #check which versions output address point id and USPS city name
#' gc_fld_by_ver[gc_fld_by_ver$GC_fldname %in% 
#'     c("FAP.ap_id","F1E.USPS_city_name"),]
#' 
#' #check which versions output joined fields
#' gc_fld_by_ver[grepl("^JN",gc_fld_by_ver$GC_fldname),]

GBAT.fields_by_version <- function(){

	gc.pks <- GBAT.load_all()
	
	DT.m2 <- data.table::rbindlist(lapply(1:nrow(gc.pks), function(x) {
		xxx <- getExportedValue(as.character(gc.pks[x,]$Package),"GBAT_output")[,c("GC_fldname","GC_comment","GC_length")]
		xxx[,GC_version := paste0("v",as.character(gc.pks[x,]$Version))]
		return(xxx)
	}))
	
	DT.m2[,c("GC_comment","GC_length") := NULL]
	
	DT.m2[,present := 1]
	
	DT.c2 = data.table::dcast(DT.m2, GC_fldname ~ GC_version, value.var = c("present"))
	
	DT.c2[is.na(DT.c2)] <- 0
	
	#########################################
	###add census fields and joined fields###
	#########################################
	
	add.flds <- joined_fields$GC_fldname
	
	DT.c2 <- rbindlist(list(DT.c2,rbindlist(lapply(add.flds,function(x) c(list(x), rep(1,length(names(DT.c2)[grepl("^v",names(DT.c2))])))))))
	
	return(as.data.frame(DT.c2))
}